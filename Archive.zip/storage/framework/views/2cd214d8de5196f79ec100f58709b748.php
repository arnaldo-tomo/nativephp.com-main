<hr <?php echo e($attributes->class(['dark:border-gray-700'])); ?>>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/separator.blade.php ENDPATH**/ ?>