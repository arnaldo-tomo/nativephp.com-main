<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['class','alt']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['class','alt']); ?>
<?php foreach (array_filter((['class','alt']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal588d3273546287a02d550f73c2c6e521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal588d3273546287a02d550f73c2c6e521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sponsors.logos.redgalaxy','data' => ['class' => $class,'alt' => $alt]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sponsors.logos.redgalaxy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class),'alt' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($alt)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal588d3273546287a02d550f73c2c6e521)): ?>
<?php $attributes = $__attributesOriginal588d3273546287a02d550f73c2c6e521; ?>
<?php unset($__attributesOriginal588d3273546287a02d550f73c2c6e521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal588d3273546287a02d550f73c2c6e521)): ?>
<?php $component = $__componentOriginal588d3273546287a02d550f73c2c6e521; ?>
<?php unset($__componentOriginal588d3273546287a02d550f73c2c6e521); ?>
<?php endif; ?><?php /**PATH /Users/dintell/Downloads/nativephp.com-main/storage/framework/views/2b2c9a0017aae59c321715cfcff22322.blade.php ENDPATH**/ ?>