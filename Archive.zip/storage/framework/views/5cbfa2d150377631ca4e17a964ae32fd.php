<div
    x-ref="sponsor"
    class="opacity-0"
>
    <a
        href="https://www.redgalaxy.co.uk/"
        class="inline-grid h-16 w-60 shrink-0 place-items-center rounded-2xl bg-gray-100 p-5 transition duration-200 hover:bg-gray-200/70 hover:ring-1 hover:ring-black/60 dark:bg-mirage dark:hover:bg-haiti dark:hover:ring-cloud"
        title="Learn more about RedGalaxy"
        aria-label="Visit RedGalaxy website"
        rel="noopener"
    >
        <?php if (isset($component)) { $__componentOriginal588d3273546287a02d550f73c2c6e521 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal588d3273546287a02d550f73c2c6e521 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sponsors.logos.redgalaxy','data' => ['class' => 'h-auto max-h-5 max-w-full','alt' => 'RedGalaxy logo','loading' => 'lazy']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sponsors.logos.redgalaxy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-auto max-h-5 max-w-full','alt' => 'RedGalaxy logo','loading' => 'lazy']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal588d3273546287a02d550f73c2c6e521)): ?>
<?php $attributes = $__attributesOriginal588d3273546287a02d550f73c2c6e521; ?>
<?php unset($__attributesOriginal588d3273546287a02d550f73c2c6e521); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal588d3273546287a02d550f73c2c6e521)): ?>
<?php $component = $__componentOriginal588d3273546287a02d550f73c2c6e521; ?>
<?php unset($__componentOriginal588d3273546287a02d550f73c2c6e521); ?>
<?php endif; ?>
        <span class="sr-only">RedGalaxy</span>
    </a>
</div>

<div
    x-ref="sponsor"
    class="opacity-0"
>
    <a
        href="https://sevalla.com/?utm_source=nativephp&utm_medium=Referral&utm_campaign=homepage"
        class="inline-grid h-16 w-60 shrink-0 place-items-center rounded-2xl bg-gray-100 p-5 transition duration-200 hover:bg-gray-200/70 hover:ring-1 hover:ring-black/60 dark:bg-mirage dark:hover:bg-haiti dark:hover:ring-cloud"
        title="Learn more about Sevalla"
        aria-label="Visit Sevalla website"
        rel="noopener"
    >
        <?php if (isset($component)) { $__componentOriginal05051760c12a41afdf50a7087299786f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05051760c12a41afdf50a7087299786f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sponsors.logos.sevalla','data' => ['class' => 'h-auto max-h-5 max-w-full text-black dark:text-white','alt' => 'Sevalla logo','loading' => 'lazy']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sponsors.logos.sevalla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-auto max-h-5 max-w-full text-black dark:text-white','alt' => 'Sevalla logo','loading' => 'lazy']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05051760c12a41afdf50a7087299786f)): ?>
<?php $attributes = $__attributesOriginal05051760c12a41afdf50a7087299786f; ?>
<?php unset($__attributesOriginal05051760c12a41afdf50a7087299786f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05051760c12a41afdf50a7087299786f)): ?>
<?php $component = $__componentOriginal05051760c12a41afdf50a7087299786f; ?>
<?php unset($__componentOriginal05051760c12a41afdf50a7087299786f); ?>
<?php endif; ?>
        <span class="sr-only">Sevalla</span>
    </a>
</div>



<div
    x-ref="sponsor"
    class="opacity-0"
>
    <a
        href="https://www.kaashosting.nl/?lang=en"
        class="inline-grid h-16 w-60 shrink-0 place-items-center rounded-2xl bg-gray-100 p-5 transition duration-200 hover:bg-gray-200/70 hover:ring-1 hover:ring-black/60 dark:bg-mirage dark:hover:bg-haiti dark:hover:ring-cloud"
        title="Learn more about KaasHosting"
        aria-label="Visit KaasHosting website"
        rel="noopener"
    >
        <?php if (isset($component)) { $__componentOriginal3b9373f52fb152cd11e5fc0edd99a99d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b9373f52fb152cd11e5fc0edd99a99d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sponsors.logos.kaashosting','data' => ['class' => 'block h-auto max-h-5 max-w-full fill-[#042340] dark:fill-white','alt' => 'KaasHosting logo','loading' => 'lazy']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sponsors.logos.kaashosting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-auto max-h-5 max-w-full fill-[#042340] dark:fill-white','alt' => 'KaasHosting logo','loading' => 'lazy']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b9373f52fb152cd11e5fc0edd99a99d)): ?>
<?php $attributes = $__attributesOriginal3b9373f52fb152cd11e5fc0edd99a99d; ?>
<?php unset($__attributesOriginal3b9373f52fb152cd11e5fc0edd99a99d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b9373f52fb152cd11e5fc0edd99a99d)): ?>
<?php $component = $__componentOriginal3b9373f52fb152cd11e5fc0edd99a99d; ?>
<?php unset($__componentOriginal3b9373f52fb152cd11e5fc0edd99a99d); ?>
<?php endif; ?>
        <span class="sr-only">KaasHosting</span>
    </a>
</div>

<div
    x-ref="sponsor"
    class="opacity-0"
>
    <a
        href="https://www.quantumweb.co/"
        class="inline-grid h-16 w-60 shrink-0 place-items-center rounded-2xl bg-gray-100 p-5 transition duration-200 hover:bg-gray-200/70 hover:ring-1 hover:ring-black/60 dark:bg-mirage dark:hover:bg-haiti dark:hover:ring-cloud"
        title="Learn more about Quantumweb"
        aria-label="Visit Quantumweb website"
        rel="noopener"
    >
        <?php if (isset($component)) { $__componentOriginalc513093657c2fe17610037bcee39a080 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc513093657c2fe17610037bcee39a080 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sponsors.logos.quantumweb','data' => ['class' => 'block h-auto max-h-5 max-w-full fill-[#042340] dark:fill-white','alt' => 'Quantumweb logo','loading' => 'lazy']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sponsors.logos.quantumweb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block h-auto max-h-5 max-w-full fill-[#042340] dark:fill-white','alt' => 'Quantumweb logo','loading' => 'lazy']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc513093657c2fe17610037bcee39a080)): ?>
<?php $attributes = $__attributesOriginalc513093657c2fe17610037bcee39a080; ?>
<?php unset($__attributesOriginalc513093657c2fe17610037bcee39a080); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc513093657c2fe17610037bcee39a080)): ?>
<?php $component = $__componentOriginalc513093657c2fe17610037bcee39a080; ?>
<?php unset($__componentOriginalc513093657c2fe17610037bcee39a080); ?>
<?php endif; ?>
        <span class="sr-only">Quantumweb</span>
    </a>
</div>


<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/sponsors/lists/home/corporate-sponsors.blade.php ENDPATH**/ ?>