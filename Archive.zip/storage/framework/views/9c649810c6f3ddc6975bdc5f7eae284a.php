<a
    <?php echo e($attributes); ?>

    class="text-sm tracking-wide text-gray-500 underline underline-offset-4 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-100"
>
    <?php echo e($slot); ?>

</a>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/link-subtle.blade.php ENDPATH**/ ?>