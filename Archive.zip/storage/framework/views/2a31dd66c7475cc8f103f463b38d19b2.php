<?php if (isset($component)) { $__componentOriginal6b4d6a898a51e4c8d3658c7fda45d6a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b4d6a898a51e4c8d3658c7fda45d6a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.docs-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('docs-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('sidebarLeft', null, []); ?> 
        <?php echo $navigation; ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('sidebarRight', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toc-and-sponsors','data' => ['tableOfContents' => $tableOfContents]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('toc-and-sponsors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tableOfContents' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tableOfContents)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8)): ?>
<?php $attributes = $__attributesOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8; ?>
<?php unset($__attributesOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8)): ?>
<?php $component = $__componentOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8; ?>
<?php unset($__componentOriginal1d2a0723b1a8a6b20fdf2affb44b9ed8); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>

    <h1 class="text-4xl font-semibold">
        <?php echo e($title); ?>

    </h1>

    <?php if (isset($component)) { $__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.separator','data' => ['class' => 'mt-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897)): ?>
<?php $attributes = $__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897; ?>
<?php unset($__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897)): ?>
<?php $component = $__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897; ?>
<?php unset($__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal7b5d53055927ae26b7663b3ff9cd87c1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b5d53055927ae26b7663b3ff9cd87c1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-v1-announcement','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-v1-announcement'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b5d53055927ae26b7663b3ff9cd87c1)): ?>
<?php $attributes = $__attributesOriginal7b5d53055927ae26b7663b3ff9cd87c1; ?>
<?php unset($__attributesOriginal7b5d53055927ae26b7663b3ff9cd87c1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b5d53055927ae26b7663b3ff9cd87c1)): ?>
<?php $component = $__componentOriginal7b5d53055927ae26b7663b3ff9cd87c1; ?>
<?php unset($__componentOriginal7b5d53055927ae26b7663b3ff9cd87c1); ?>
<?php endif; ?>

    
    <div class="xl:hidden">
        <h3 class="inline-flex items-center gap-1.5 pt-5 text-sm opacity-50">
            
            <?php if (isset($component)) { $__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.stacked-lines','data' => ['class' => 'size-[18px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.stacked-lines'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[18px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846)): ?>
<?php $attributes = $__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846; ?>
<?php unset($__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846)): ?>
<?php $component = $__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846; ?>
<?php unset($__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846); ?>
<?php endif; ?>
            
            <div>On this page</div>
        </h3>
        <?php if(count($tableOfContents) > 0): ?>
            <div
                class="mt-2 flex flex-col space-y-2 border-l text-xs dark:border-l-white/15"
            >
                <?php $__currentLoopData = $tableOfContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a
                        href="#<?php echo e($item['anchor']); ?>"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'transition duration-300 ease-in-out will-change-transform hover:translate-x-0.5 hover:text-violet-400 hover:opacity-100 dark:text-white/80',
                            'pb-1 pl-3' => $item['level'] == 2,
                            'py-1 pl-6' => $item['level'] == 3,
                        ]); ?>"
                    >
                        <?php echo e($item['title']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

    <div
        class="prose dark:prose-invert prose-headings:scroll-mt-20 prose-headings:text-gray-800 sm:prose-headings:scroll-mt-32 dark:prose-headings:text-gray-50 mt-8 max-w-none"
    >
        <?php echo $content; ?>

    </div>

    <?php if (isset($component)) { $__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.separator','data' => ['class' => 'mt-8']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('separator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897)): ?>
<?php $attributes = $__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897; ?>
<?php unset($__attributesOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897)): ?>
<?php $component = $__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897; ?>
<?php unset($__componentOriginal6ae7ff41cc5b9d4e0c19f47c83a8f897); ?>
<?php endif; ?>

    <?php
        $linkAlign = $previousPage === null ? 'right' : 'between';
    ?>

    <?php if (isset($component)) { $__componentOriginald73cf7c177de1a5d0dbb65f12b921fd5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald73cf7c177de1a5d0dbb65f12b921fd5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.flex-list-of-links','data' => ['align' => ''.e($linkAlign).'','class' => 'mt-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('flex-list-of-links'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => ''.e($linkAlign).'','class' => 'mt-5']); ?>
        <?php if($previousPage !== null): ?>
            <?php if (isset($component)) { $__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-button','data' => ['href' => ''.e($previousPage['path']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e($previousPage['path']).'']); ?>
                <div class="self-center justify-self-start">
                    <div
                        class="flex items-center justify-start gap-1.5 opacity-60"
                    >
                        <?php if (isset($component)) { $__componentOriginal08f988fc2664185931526331a58d5ce9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal08f988fc2664185931526331a58d5ce9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.right-arrow','data' => ['class' => 'size-3 shrink-0 -scale-x-100']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.right-arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-3 shrink-0 -scale-x-100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal08f988fc2664185931526331a58d5ce9)): ?>
<?php $attributes = $__attributesOriginal08f988fc2664185931526331a58d5ce9; ?>
<?php unset($__attributesOriginal08f988fc2664185931526331a58d5ce9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08f988fc2664185931526331a58d5ce9)): ?>
<?php $component = $__componentOriginal08f988fc2664185931526331a58d5ce9; ?>
<?php unset($__componentOriginal08f988fc2664185931526331a58d5ce9); ?>
<?php endif; ?>
                        <div class="text-sm">Previous</div>
                    </div>
                    <div class="pt-1"><?php echo e($previousPage['title']); ?></div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379)): ?>
<?php $attributes = $__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379; ?>
<?php unset($__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379)): ?>
<?php $component = $__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379; ?>
<?php unset($__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php if($nextPage !== null): ?>
            <?php if (isset($component)) { $__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-button','data' => ['href' => ''.e($nextPage['path']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e($nextPage['path']).'']); ?>
                <div class="self-center justify-self-end">
                    <div
                        class="flex items-center justify-end gap-1.5 opacity-60"
                    >
                        <div class="text-sm">Next</div>
                        <?php if (isset($component)) { $__componentOriginal08f988fc2664185931526331a58d5ce9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal08f988fc2664185931526331a58d5ce9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.right-arrow','data' => ['class' => 'size-3 shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.right-arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-3 shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal08f988fc2664185931526331a58d5ce9)): ?>
<?php $attributes = $__attributesOriginal08f988fc2664185931526331a58d5ce9; ?>
<?php unset($__attributesOriginal08f988fc2664185931526331a58d5ce9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08f988fc2664185931526331a58d5ce9)): ?>
<?php $component = $__componentOriginal08f988fc2664185931526331a58d5ce9; ?>
<?php unset($__componentOriginal08f988fc2664185931526331a58d5ce9); ?>
<?php endif; ?>
                    </div>
                    <div class="pt-1"><?php echo e($nextPage['title']); ?></div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379)): ?>
<?php $attributes = $__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379; ?>
<?php unset($__attributesOriginalfb5b48b69fbd6989c24c2377cf6cf379); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379)): ?>
<?php $component = $__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379; ?>
<?php unset($__componentOriginalfb5b48b69fbd6989c24c2377cf6cf379); ?>
<?php endif; ?>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald73cf7c177de1a5d0dbb65f12b921fd5)): ?>
<?php $attributes = $__attributesOriginald73cf7c177de1a5d0dbb65f12b921fd5; ?>
<?php unset($__attributesOriginald73cf7c177de1a5d0dbb65f12b921fd5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald73cf7c177de1a5d0dbb65f12b921fd5)): ?>
<?php $component = $__componentOriginald73cf7c177de1a5d0dbb65f12b921fd5; ?>
<?php unset($__componentOriginald73cf7c177de1a5d0dbb65f12b921fd5); ?>
<?php endif; ?>

    <div class="pt-5 text-center sm:text-left">
        <?php if (isset($component)) { $__componentOriginalf55baf7e00428ca3cb7d0512f0918c3f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf55baf7e00428ca3cb7d0512f0918c3f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-subtle','data' => ['href' => ''.e($editUrl).'','target' => '_blank','rel' => 'noopener']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-subtle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e($editUrl).'','target' => '_blank','rel' => 'noopener']); ?>
            Edit this page on GitHub
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf55baf7e00428ca3cb7d0512f0918c3f)): ?>
<?php $attributes = $__attributesOriginalf55baf7e00428ca3cb7d0512f0918c3f; ?>
<?php unset($__attributesOriginalf55baf7e00428ca3cb7d0512f0918c3f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf55baf7e00428ca3cb7d0512f0918c3f)): ?>
<?php $component = $__componentOriginalf55baf7e00428ca3cb7d0512f0918c3f; ?>
<?php unset($__componentOriginalf55baf7e00428ca3cb7d0512f0918c3f); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b4d6a898a51e4c8d3658c7fda45d6a9)): ?>
<?php $attributes = $__attributesOriginal6b4d6a898a51e4c8d3658c7fda45d6a9; ?>
<?php unset($__attributesOriginal6b4d6a898a51e4c8d3658c7fda45d6a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b4d6a898a51e4c8d3658c7fda45d6a9)): ?>
<?php $component = $__componentOriginal6b4d6a898a51e4c8d3658c7fda45d6a9; ?>
<?php unset($__componentOriginal6b4d6a898a51e4c8d3658c7fda45d6a9); ?>
<?php endif; ?>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/docs/index.blade.php ENDPATH**/ ?>