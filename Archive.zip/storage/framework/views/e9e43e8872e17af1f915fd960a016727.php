<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'align' => 'left',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'align' => 'left',
]); ?>
<?php foreach (array_filter(([
    'align' => 'left',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div <?php echo e($attributes->class([
    'flex sm:flex-row items-center gap-x-6 gap-y-4',
    'justify-start flex-col-reverse' => $align === 'left',
    'justify-center flex-col' => $align === 'center',
    'justify-between flex-col-reverse' => $align === 'between',
    'justify-end flex-col-reverse' => $align === 'right'
    ])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/flex-list-of-links.blade.php ENDPATH**/ ?>