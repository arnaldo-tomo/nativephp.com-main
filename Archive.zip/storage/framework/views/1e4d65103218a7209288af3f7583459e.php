<div
    class="relative z-0 mt-5 flex flex-col items-start gap-3 overflow-hidden rounded-2xl bg-[#f9f8f6] p-4 ring-1 ring-black/5 min-[450px]:flex-row min-[450px]:items-center dark:bg-mirage"
    role="alert"
    aria-labelledby="beta-alert-title"
    aria-describedby="beta-alert-description"
>
    
    <div
        class="absolute left-6 top-0 -z-10 hidden h-32 w-6 -rotate-60 rounded-full blur-lg min-[450px]:top-1/2 min-[450px]:-translate-y-1/2 dark:block dark:bg-linear-to-b dark:from-blue-500 dark:to-blue-500/10"
        aria-hidden="true"
    ></div>

    
    <div
        class="absolute left-20 top-0 -z-20 hidden h-32 w-3 -rotate-60 rounded-full blur-lg min-[450px]:top-1/2 min-[450px]:-translate-y-1/2 dark:block dark:bg-linear-to-b dark:from-white/30 dark:to-transparent"
        aria-hidden="true"
    ></div>

    
    <div
        class="grid size-10 place-items-center rounded-full bg-gray-200/50 backdrop-blur-xs dark:bg-black/30"
        aria-hidden="true"
    >
        <?php if (isset($component)) { $__componentOriginal90435258525479a712acdcb6e96f143a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90435258525479a712acdcb6e96f143a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.colored-confetti','data' => ['class' => '-mr-px size-[22px] shrink-0 mix-blend-multiply dark:hidden','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.colored-confetti'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '-mr-px size-[22px] shrink-0 mix-blend-multiply dark:hidden','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90435258525479a712acdcb6e96f143a)): ?>
<?php $attributes = $__attributesOriginal90435258525479a712acdcb6e96f143a; ?>
<?php unset($__attributesOriginal90435258525479a712acdcb6e96f143a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90435258525479a712acdcb6e96f143a)): ?>
<?php $component = $__componentOriginal90435258525479a712acdcb6e96f143a; ?>
<?php unset($__componentOriginal90435258525479a712acdcb6e96f143a); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal9950c17d3b05219f77efd503ebcb9218 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9950c17d3b05219f77efd503ebcb9218 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.confetti','data' => ['class' => 'hidden size-5 shrink-0 dark:block','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.confetti'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden size-5 shrink-0 dark:block','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9950c17d3b05219f77efd503ebcb9218)): ?>
<?php $attributes = $__attributesOriginal9950c17d3b05219f77efd503ebcb9218; ?>
<?php unset($__attributesOriginal9950c17d3b05219f77efd503ebcb9218); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9950c17d3b05219f77efd503ebcb9218)): ?>
<?php $component = $__componentOriginal9950c17d3b05219f77efd503ebcb9218; ?>
<?php unset($__componentOriginal9950c17d3b05219f77efd503ebcb9218); ?>
<?php endif; ?>
    </div>

    
    <h2 class="font-medium">
    É oficial! #LARAVELLUSOPHONE v1.0 chegou com tudo!
    </h2>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random() * 1.5,
                    },
                )
            }
        "
        class="absolute -left-3 top-2 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 - 5,
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random(),
                    },
                )
            }
        "
        class="absolute -left-3 top-3.5 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random() * 1.5,
                    },
                )
            }
        "
        class="absolute -left-3 top-5 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 - 5,
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random(),
                    },
                )
            }
        "
        class="absolute -left-3 top-7 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random() * 1.5,
                    },
                )
            }
        "
        class="absolute -left-3 top-10 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 - 5,
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random(),
                    },
                )
            }
        "
        class="absolute -left-3 top-12 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random() * 1.5,
                    },
                )
            }
        "
        class="absolute -left-3 top-14 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>

    
    <div
        x-init="
            () => {
                motion.animate(
                    $el,
                    {
                        opacity: [0, 1, 0],
                        y: [
                            Math.random() * 10 - 5,
                            Math.random() * 10 + 5,
                            Math.random() * 10 - 5,
                        ],
                        x: [Math.random() * 10 - 5, 120],
                    },
                    {
                        duration: Math.random() * 5 + 3,
                        repeat: Infinity,
                        repeatType: 'loop',
                        ease: motion.easeInOut,
                        delay: Math.random(),
                    },
                )
            }
        "
        class="absolute -left-3 top-16 -z-50 hidden size-0.5 rounded-full bg-white dark:block"
        aria-hidden="true"
    ></div>
</div>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/alert-v1-announcement.blade.php ENDPATH**/ ?>