<svg
    <?php echo e($attributes); ?>

    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
>
    <path
        d="M22.68 11.59a3.13 3.13 0 0 0 -4.35 0 0.75 0.75 0 0 1 -1.06 0 0.74 0.74 0 0 1 0 -1.06 4.57 4.57 0 0 1 6.47 0 0.75 0.75 0 1 1 -1.06 1.06Z"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M19.95 14.56a0.81 0.81 0 1 0 1.62 0 0.81 0.81 0 1 0 -1.62 0"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M12.41 6.73a0.75 0.75 0 0 1 0 -1.06 3.08 3.08 0 0 0 0 -4.35 0.75 0.75 0 0 1 1.06 -1.06 4.57 4.57 0 0 1 0 6.47 0.74 0.74 0 0 1 -1.06 0Z"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M8.63 3.24a0.81 0.81 0 1 0 1.62 0 0.81 0.81 0 1 0 -1.62 0"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M22.38 0.81a0.81 0.81 0 1 0 1.62 0 0.81 0.81 0 1 0 -1.62 0"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M22.11 6.47a0.81 0.81 0 1 0 1.62 0 0.81 0.81 0 1 0 -1.62 0"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M15.65 8.35a0.75 0.75 0 0 1 0 -1.06l5.12 -5.12a0.75 0.75 0 0 1 1.06 1.06l-5.12 5.12a0.75 0.75 0 0 1 -1.06 0Z"
        fill="currentColor"
        stroke-width="1"
    ></path>
    <path
        d="M14 10c-2.21 -2.24 -5.31 -3.64 -6.91 -2a1.66 1.66 0 0 0 -0.36 0.48C6.69 8.51 0.28 20.52 0.28 20.52a2.38 2.38 0 0 0 0.41 2.79 2.37 2.37 0 0 0 2.78 0.41l12 -6.41a1.79 1.79 0 0 0 0.57 -0.4c1.6 -1.61 0.2 -4.7 -2.04 -6.91Zm0.49 5.4c-0.35 0.36 -2.37 -0.52 -3.87 -2s-2.37 -3.52 -2 -3.87c0.15 -0.15 1.77 -0.08 3.88 2 1.89 1.88 2.24 3.63 2.01 3.85Z"
        fill="currentColor"
        stroke-width="1"
    ></path>
</svg>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/icons/confetti.blade.php ENDPATH**/ ?>