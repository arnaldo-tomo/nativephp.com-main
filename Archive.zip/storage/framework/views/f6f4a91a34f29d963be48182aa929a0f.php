<aside
    class="sticky top-20 hidden max-h-[clamp(15rem,100svh,88svh)] w-68 shrink-0 flex-col overflow-y-auto overflow-x-hidden px-3 py-4 xl:flex"
>
    <?php echo e($slot); ?>

</aside>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/sidebar-right.blade.php ENDPATH**/ ?>