<div
    x-collapse
    x-show="!showMobileMenu"
>
    
    
</div>
<nav
    class="sticky top-0 z-50 flex flex-col items-center justify-center px-3 pt-px"
    aria-label="Main Navigation"
>
    <div
        :class="{
            'ring-gray-200/80 backdrop-blur-2xl dark:ring-gray-700/70 bg-white/50 dark:bg-black/50 translate-y-3': scrolled || showMobileMenu,
            'ring-transparent dark:bg-transparent': ! scrolled && ! showMobileMenu,
        }"
        class="mx-auto flex w-full max-w-5xl items-center justify-between gap-5 rounded-2xl px-5 py-4 ring-1 transition duration-200 ease-out xl:max-w-7xl 2xl:max-w-360"
    >
        
        <div class="flex items-center gap-3">
            
            <a
                href="/"
                aria-label="laravelLusophone Homepage"
            >
                <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['class' => 'h-4 min-[400px]:h-5 sm:h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-4 min-[400px]:h-5 sm:h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
                <span class="sr-only">laravelLusophone</span>
            </a>

            
            <a
                href="https://github.com/arnaldo-tomo/laravel-lusophone"
                class="group relative z-0 hidden items-center overflow-hidden rounded-full bg-gray-200 px-2.5 py-1.5 text-xs transition duration-200 will-change-transform hover:scale-x-105 lg:inline-flex dark:bg-slate-800"
                target="_blank"
                aria-label="Read about laravelLusophone version 1 release"
                title="Read the laravelLusophone v1 announcement"
            >
                <div
                    class="@container absolute inset-0 flex items-center"
                    aria-hidden="true"
                >
                    <div
                        class="absolute h-[100cqw] w-[100cqw] animate-[spin_2.5s_linear_infinite] bg-[conic-gradient(from_0_at_50%_50%,rgba(167,139,250,0.75)_0deg,transparent_60deg,transparent_300deg,rgba(167,139,250,0.75)_360deg)] transition duration-300"
                    ></div>
                </div>

                <div
                    class="absolute inset-0.5 rounded-full bg-violet-50 dark:bg-slate-950"
                    aria-hidden="true"
                ></div>

                <div
                    class="absolute bottom-0 left-1/2 h-1/3 w-4/5 -translate-x-1/2 rounded-full bg-orange-300 opacity-50 blur-md transition-all duration-500 dark:bg-fuchsia-300/30 dark:group-hover:h-2/3 dark:group-hover:opacity-100"
                    aria-hidden="true"
                ></div>

                <span class="relative inline-flex items-center gap-1">
                    <?php if (isset($component)) { $__componentOriginal9950c17d3b05219f77efd503ebcb9218 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9950c17d3b05219f77efd503ebcb9218 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.confetti','data' => ['class' => '-mt-px size-3.5','ariaHidden' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.confetti'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '-mt-px size-3.5','aria-hidden' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9950c17d3b05219f77efd503ebcb9218)): ?>
<?php $attributes = $__attributesOriginal9950c17d3b05219f77efd503ebcb9218; ?>
<?php unset($__attributesOriginal9950c17d3b05219f77efd503ebcb9218); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9950c17d3b05219f77efd503ebcb9218)): ?>
<?php $component = $__componentOriginal9950c17d3b05219f77efd503ebcb9218; ?>
<?php unset($__componentOriginal9950c17d3b05219f77efd503ebcb9218); ?>
<?php endif; ?>
                    <span class="font-normal">v1 está aqui!!</span>
                    <span class="sr-only">
               A versão 1 do laravelLusophone foi lançada - clique para saber mais
                    </span>
                </span>
            </a>

            
            

                <div
                class="hidden rounded-full bg-gray-200/60 px-2 py-1 text-xs text-gray-600 lg:block dark:bg-[#16182b] dark:text-[#747ee6] dark:ring-1 dark:ring-cloud"
                aria-label="Version information"
                >
                <a href="/docs/desktop/1/getting-started/releasenotes">
                <?php echo e($electronGitHubVersion); ?>

                </a>
                </div>

        </div>

        
        <div class="flex items-center gap-3.5">
            
            <div
                class="-mr-0.5 transition-all duration-200 ease-in-out will-change-transform"
                :class="{
                    'pr-0.5': showMobileMenu,
                }"
            >
                <div
                    id="docsearch"
                    x-on:click="if (window.innerWidth < 640) window.scrollTo({ top: 0, behavior: 'instant' })"
                    aria-label="Search documentation"
                ></div>
            </div>

            
            

            
            <div
                class="hidden items-center gap-3.5 text-sm lg:flex"
                aria-label="Primary navigation"
            >
                
                <a
                    href="/"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'transition duration-200',
                        'font-medium' => request()->routeIs('welcome*'),
                        'opacity-60 hover:opacity-100' => ! request()->routeIs('welcome*'),
                    ]); ?>"
                    aria-current="<?php echo e(request()->routeIs('welcome*') ? 'page' : 'false'); ?>"
                >
                    Home
                </a>

                
                <div
                    class="size-[3px] rotate-45 rounded-xs bg-gray-400 transition duration-200 dark:opacity-60"
                    aria-hidden="true"
                ></div>



                
                <div
                    class="size-[3px] rotate-45 rounded-xs bg-gray-400 transition duration-200 dark:opacity-60"
                    aria-hidden="true"
                ></div>

                
                <a
                    href="/docs/"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'transition duration-200',
                        'font-medium' => request()->is('docs*'),
                        'opacity-60 hover:opacity-100' => ! request()->is('docs*'),
                    ]); ?>"
                    aria-current="<?php echo e(request()->is('docs*') ? 'page' : 'false'); ?>"
                >
                    Docs
                </a>

                
                <div
                    class="size-[3px] rotate-45 rounded-xs bg-gray-400 transition duration-200 dark:opacity-60"
                    aria-hidden="true"
                ></div>

                
                <a
                    href="#"
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'transition duration-200',
                        'font-medium' => request()->routeIs('blog*'),
                        'opacity-60 hover:opacity-100' => ! request()->routeIs('blog*'),
                    ]); ?>"
                    aria-current="<?php echo e(request()->routeIs('blog*') ? 'page' : 'false'); ?>"
                >
                    Blog
                </a>

                
                <div
                    class="size-[3px] rotate-45 rounded-xs bg-gray-400 transition duration-200 dark:opacity-60"
                    aria-hidden="true"
                ></div>

                
                <a
                    x-init="
                        () => {
                            motion.hover($el, (element) => {
                                motion.animate(
                                    $refs.sponsorHeart1,
                                    {
                                        y: -8,
                                        x: 6,
                                        opacity: 1,
                                        scale: 1,
                                    },
                                    {
                                        duration: 0.25,
                                        ease: motion.backOut,
                                    },
                                )
                                motion.animate(
                                    $refs.sponsorHeart2,
                                    {
                                        y: -15,
                                        x: -9,
                                        opacity: 1,
                                        scale: 1,
                                        rotate: -20,
                                    },
                                    {
                                        duration: 0.25,
                                        ease: motion.backOut,
                                        delay: 0.05,
                                    },
                                )
                                motion.animate(
                                    $refs.sponsorHeart3,
                                    {
                                        y: -16,
                                        x: 7,
                                        opacity: 1,
                                        scale: 1,
                                        rotate: 20,
                                    },
                                    {
                                        duration: 0.25,
                                        ease: motion.backOut,
                                        delay: 0.1,
                                    },
                                )

                                return () =>
                                    motion.animate(
                                        [$refs.sponsorHeart1, $refs.sponsorHeart2, $refs.sponsorHeart3],
                                        {
                                            y: 0,
                                            x: 0,
                                            opacity: 0,
                                            scale: 0,
                                            rotate: 0,
                                        },
                                        {
                                            duration: 0.25,
                                            ease: motion.backIn,
                                        },
                                    )
                            })
                        }
                    "
                    href="#/sponsor"
                    class="relative bg-linear-to-tr from-violet-600 to-violet-300 bg-clip-text font-medium text-transparent dark:from-violet-500 dark:to-white/80"
                    aria-label="Sponsor laravelLusophone"
                    title="Support laravelLusophone development"
                >
                    Sponsor
                    <span class="sr-only">laravelLusophone on GitHub</span>

                    
                    <div
                        x-ref="sponsorHeart1"
                        class="absolute top-0 right-1/2 origin-center scale-0 opacity-0"
                        aria-hidden="true"
                    >
                        <?php if (isset($component)) { $__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.heart','data' => ['class' => 'size-[9px] text-violet-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.heart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[9px] text-violet-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2)): ?>
<?php $attributes = $__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2; ?>
<?php unset($__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2)): ?>
<?php $component = $__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2; ?>
<?php unset($__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2); ?>
<?php endif; ?>
                    </div>

                    
                    <div
                        x-ref="sponsorHeart2"
                        class="absolute top-0 left-1/2 origin-center scale-0 opacity-0"
                        aria-hidden="true"
                    >
                        <?php if (isset($component)) { $__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.heart','data' => ['class' => 'size-[7px] text-violet-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.heart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[7px] text-violet-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2)): ?>
<?php $attributes = $__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2; ?>
<?php unset($__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2)): ?>
<?php $component = $__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2; ?>
<?php unset($__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2); ?>
<?php endif; ?>
                    </div>

                    
                    <div
                        x-ref="sponsorHeart3"
                        class="absolute top-0 right-1/2 origin-center scale-0 opacity-0"
                        aria-hidden="true"
                    >
                        <?php if (isset($component)) { $__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.heart','data' => ['class' => 'size-[5px] text-violet-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.heart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[5px] text-violet-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2)): ?>
<?php $attributes = $__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2; ?>
<?php unset($__attributesOriginala8a696c0067ca4fbabcc40e90c22e3a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2)): ?>
<?php $component = $__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2; ?>
<?php unset($__componentOriginala8a696c0067ca4fbabcc40e90c22e3a2); ?>
<?php endif; ?>
                    </div>

                    
                    <div
                        x-init="
                            () => {
                                motion.animate(
                                    $el,
                                    {
                                        x: [-5, 50],
                                        scaleX: [1, 2.5, 1],
                                        opacity: [0, 1, 1, 1, 0],
                                    },
                                    {
                                        duration: 1.8,
                                        repeat: Infinity,
                                        repeatType: 'reverse',
                                        ease: motion.easeInOut,
                                    },
                                )
                            }
                        "
                        class="absolute -bottom-1 left-0 h-0.5 w-2 origin-left rounded-full bg-violet-400 will-change-transform dark:bg-violet-500"
                        aria-hidden="true"
                    ></div>

                    
                    <div
                        x-init="
                            () => {
                                motion.animate(
                                    $el,
                                    {
                                        x: [-5, 50],
                                        scaleX: [1, 2.5, 1],
                                        opacity: [0, 1, 1, 1, 0],
                                    },
                                    {
                                        duration: 1.8,
                                        repeat: Infinity,
                                        repeatType: 'reverse',
                                        ease: motion.easeInOut,
                                    },
                                )
                            }
                        "
                        class="absolute -bottom-1.5 left-0 h-8 w-2 origin-left rounded-full bg-linear-to-t from-violet-500 to-transparent blur-[9px] will-change-transform dark:blur-xs"
                        aria-hidden="true"
                    ></div>
                </a>

                
                <?php if (isset($component)) { $__componentOriginal2090438866f3dcdb76cd8b070bcc302d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2090438866f3dcdb76cd8b070bcc302d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.theme-toggle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('theme-toggle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2090438866f3dcdb76cd8b070bcc302d)): ?>
<?php $attributes = $__attributesOriginal2090438866f3dcdb76cd8b070bcc302d; ?>
<?php unset($__attributesOriginal2090438866f3dcdb76cd8b070bcc302d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2090438866f3dcdb76cd8b070bcc302d)): ?>
<?php $component = $__componentOriginal2090438866f3dcdb76cd8b070bcc302d; ?>
<?php unset($__componentOriginal2090438866f3dcdb76cd8b070bcc302d); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/navigation-bar.blade.php ENDPATH**/ ?>