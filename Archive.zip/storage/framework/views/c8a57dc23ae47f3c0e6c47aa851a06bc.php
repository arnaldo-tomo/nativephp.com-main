<div>
    <a
        href="https://x.com/nativephp"
        title="Twitter"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginala14b67a17cec523d3bc8f40208ee0ef9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala14b67a17cec523d3bc8f40208ee0ef9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.twitter','data' => ['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.twitter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala14b67a17cec523d3bc8f40208ee0ef9)): ?>
<?php $attributes = $__attributesOriginala14b67a17cec523d3bc8f40208ee0ef9; ?>
<?php unset($__attributesOriginala14b67a17cec523d3bc8f40208ee0ef9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala14b67a17cec523d3bc8f40208ee0ef9)): ?>
<?php $component = $__componentOriginala14b67a17cec523d3bc8f40208ee0ef9; ?>
<?php unset($__componentOriginala14b67a17cec523d3bc8f40208ee0ef9); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://youtube.com/@NativePHPOfficial"
        title="Youtube"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginal4264b316fb7dd2921d622fbdacbeb877 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4264b316fb7dd2921d622fbdacbeb877 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.youtube','data' => ['class' => 'size-[1.4rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.youtube'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.4rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4264b316fb7dd2921d622fbdacbeb877)): ?>
<?php $attributes = $__attributesOriginal4264b316fb7dd2921d622fbdacbeb877; ?>
<?php unset($__attributesOriginal4264b316fb7dd2921d622fbdacbeb877); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4264b316fb7dd2921d622fbdacbeb877)): ?>
<?php $component = $__componentOriginal4264b316fb7dd2921d622fbdacbeb877; ?>
<?php unset($__componentOriginal4264b316fb7dd2921d622fbdacbeb877); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://bsky.app/profile/nativephp.com"
        title="Bluesky"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginale34d03f60781c168cbc5ae39789a8de0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale34d03f60781c168cbc5ae39789a8de0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.bluesky','data' => ['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.bluesky'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale34d03f60781c168cbc5ae39789a8de0)): ?>
<?php $attributes = $__attributesOriginale34d03f60781c168cbc5ae39789a8de0; ?>
<?php unset($__attributesOriginale34d03f60781c168cbc5ae39789a8de0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale34d03f60781c168cbc5ae39789a8de0)): ?>
<?php $component = $__componentOriginale34d03f60781c168cbc5ae39789a8de0; ?>
<?php unset($__componentOriginale34d03f60781c168cbc5ae39789a8de0); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://discord.gg/X62tWNStZK"
        title="Go to discord server"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginal6ecacee1f4a5ca6279e52b8db33f7242 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ecacee1f4a5ca6279e52b8db33f7242 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.discord','data' => ['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.discord'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ecacee1f4a5ca6279e52b8db33f7242)): ?>
<?php $attributes = $__attributesOriginal6ecacee1f4a5ca6279e52b8db33f7242; ?>
<?php unset($__attributesOriginal6ecacee1f4a5ca6279e52b8db33f7242); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ecacee1f4a5ca6279e52b8db33f7242)): ?>
<?php $component = $__componentOriginal6ecacee1f4a5ca6279e52b8db33f7242; ?>
<?php unset($__componentOriginal6ecacee1f4a5ca6279e52b8db33f7242); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://opencollective.com/nativephp"
        title="NativePHP on Open Collective"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginal741f667c7f14cb0c7084c5436cf091cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal741f667c7f14cb0c7084c5436cf091cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.opencollective','data' => ['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.opencollective'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal741f667c7f14cb0c7084c5436cf091cf)): ?>
<?php $attributes = $__attributesOriginal741f667c7f14cb0c7084c5436cf091cf; ?>
<?php unset($__attributesOriginal741f667c7f14cb0c7084c5436cf091cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal741f667c7f14cb0c7084c5436cf091cf)): ?>
<?php $component = $__componentOriginal741f667c7f14cb0c7084c5436cf091cf; ?>
<?php unset($__componentOriginal741f667c7f14cb0c7084c5436cf091cf); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://github.com/nativephp"
        title="Source code of NativePHP"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginalce9d988ce8fad6a17e1109323f710ec1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce9d988ce8fad6a17e1109323f710ec1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.github','data' => ['class' => 'size-[1.1rem] transition duration-200 group-hover:fill-violet-400 dark:fill-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.github'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.1rem] transition duration-200 group-hover:fill-violet-400 dark:fill-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce9d988ce8fad6a17e1109323f710ec1)): ?>
<?php $attributes = $__attributesOriginalce9d988ce8fad6a17e1109323f710ec1; ?>
<?php unset($__attributesOriginalce9d988ce8fad6a17e1109323f710ec1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce9d988ce8fad6a17e1109323f710ec1)): ?>
<?php $component = $__componentOriginalce9d988ce8fad6a17e1109323f710ec1; ?>
<?php unset($__componentOriginalce9d988ce8fad6a17e1109323f710ec1); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://pinkary.com/@nativephp"
        title="NativePHP on Pinkary"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginal5733ce71da698563444dd92cf6a78538 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5733ce71da698563444dd92cf6a78538 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.pinkary','data' => ['class' => 'size-[1.6rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.pinkary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.6rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5733ce71da698563444dd92cf6a78538)): ?>
<?php $attributes = $__attributesOriginal5733ce71da698563444dd92cf6a78538; ?>
<?php unset($__attributesOriginal5733ce71da698563444dd92cf6a78538); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5733ce71da698563444dd92cf6a78538)): ?>
<?php $component = $__componentOriginal5733ce71da698563444dd92cf6a78538; ?>
<?php unset($__componentOriginal5733ce71da698563444dd92cf6a78538); ?>
<?php endif; ?>
    </a>
</div>

<div>
    <a
        href="https://www.linkedin.com/company/nativephp/"
        title="NativePHP on LinkedIn"
        class="group dark:hover:bg-haiti inline-grid size-10 place-items-center rounded-xl bg-zinc-200/80 transition duration-200 hover:bg-gray-200/70 dark:bg-gray-700/40"
    >
        <?php if (isset($component)) { $__componentOriginalf887a8bd15c5a211b880c96f0e212bc5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.linkedin','data' => ['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.linkedin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[1.1rem] text-black transition duration-200 group-hover:text-violet-400 dark:text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5)): ?>
<?php $attributes = $__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5; ?>
<?php unset($__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf887a8bd15c5a211b880c96f0e212bc5)): ?>
<?php $component = $__componentOriginalf887a8bd15c5a211b880c96f0e212bc5; ?>
<?php unset($__componentOriginalf887a8bd15c5a211b880c96f0e212bc5); ?>
<?php endif; ?>
    </a>
</div>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/social-networks-all.blade.php ENDPATH**/ ?>