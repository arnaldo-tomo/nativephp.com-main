---
title: Release Notes
order: 1100
---

## NativePHP/electron
<?php $__empty_1 = true; $__currentLoopData = \App\Support\GitHub::electron()->releases()->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
### <?php echo e($release->name); ?>

**Released: <?php echo e(\Carbon\Carbon::parse($release->published_at)->format('F j, Y')); ?>**

<?php echo e($release->getBodyForMarkdown()); ?>

---
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
## We couldn't show you the latest release notes at this time.
Not to worry, you can head over to GitHub to see the [latest release notes](https://github.com/NativePHP/electron/releases).
<?php endif; ?>

## NativePHP/laravel
<?php $__empty_1 = true; $__currentLoopData = \App\Support\GitHub::laravel()->releases()->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
### <?php echo e($release->name); ?>

**Released: <?php echo e(\Carbon\Carbon::parse($release->published_at)->format('F j, Y')); ?>**

<?php echo e($release->getBodyForMarkdown()); ?>

---
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
## We couldn't show you the latest release notes at this time.
Not to worry, you can head over to GitHub to see the [latest release notes](https://github.com/NativePHP/electron/releases).
<?php endif; ?>

## NativePHP/php-bin
<?php $__empty_1 = true; $__currentLoopData = \App\Support\GitHub::phpBin()->releases()->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $release): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
### <?php echo e($release->name); ?>

**Released: <?php echo e(\Carbon\Carbon::parse($release->published_at)->format('F j, Y')); ?>**

<?php echo e($release->getBodyForMarkdown()); ?>

---
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
## We couldn't show you the latest release notes at this time.
Not to worry, you can head over to GitHub to see the [latest release notes](https://github.com/NativePHP/electron/releases).
<?php endif; ?>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/docs/desktop/1/getting-started/releasenotes.md ENDPATH**/ ?>