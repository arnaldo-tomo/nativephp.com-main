<svg
    <?php echo e($attributes); ?>

    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 29 27"
    fill="none"
>
    <path
        d="M18.5169 22.7385L27.6262 13.6292L18.352 13.6533C21.7382 13.6444 23.4535 17.7262 21.0774 20.1388L18.5169 22.7385Z"
        fill="currentColor"
    />
    <path
        d="M27.6262 13.6292L21.5534 7.55634L18.5169 4.51991L21.0727 7.09425C23.4799 9.51891 21.7686 13.6444 18.352 13.6533L27.6262 13.6292Z"
        fill="currentColor"
    />
    <path
        d="M1.11537 13.6292L18.352 13.6533M27.6262 13.6292L21.5534 7.55634L18.5169 4.51991M27.6262 13.6292L18.5169 22.7385M27.6262 13.6292L18.352 13.6533M15.4805 1.48349L18.5169 4.51991M15.4805 25.7749L18.5169 22.7385M18.5169 4.51991L21.0727 7.09425C23.4799 9.51891 21.7686 13.6444 18.352 13.6533V13.6533M18.5169 22.7385L21.0774 20.1388C23.4535 17.7262 21.7382 13.6444 18.352 13.6533V13.6533"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
</svg>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/icons/right-arrow.blade.php ENDPATH**/ ?>