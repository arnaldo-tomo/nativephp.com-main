
<h3 class="flex items-center gap-1.5 text-sm opacity-60">
    
    <?php if (isset($component)) { $__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.stacked-lines','data' => ['class' => 'size-[18px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.stacked-lines'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[18px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846)): ?>
<?php $attributes = $__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846; ?>
<?php unset($__attributesOriginal6a9bcb0e40875e9f1c27264eb9c45846); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846)): ?>
<?php $component = $__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846; ?>
<?php unset($__componentOriginal6a9bcb0e40875e9f1c27264eb9c45846); ?>
<?php endif; ?>

    
    <div>On this page</div>
</h3>


<?php if(count($tableOfContents) > 0): ?>
    <div
        class="mt-4 flex min-h-20 flex-col space-y-2 overflow-y-auto overflow-x-hidden border-l text-xs dark:border-l-white/15"
    >
        <?php $__currentLoopData = $tableOfContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a
                href="#<?php echo e($item['anchor']); ?>"
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'transition duration-300 ease-in-out will-change-transform hover:translate-x-0.5 hover:text-violet-400 hover:opacity-100 dark:text-white/80',
                    'pb-1 pl-3' => $item['level'] == 2,
                    'py-1 pl-6' => $item['level'] == 3,
                ]); ?>"
            >
                <?php echo e($item['title']); ?>

            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<div
    class="mt-7 max-w-52 border-t border-t-black/20 pt-5 dark:border-t-white/15"
>
    
    <h3 class="flex items-center gap-1.5 text-sm opacity-60">
        
        <?php if (isset($component)) { $__componentOriginal47bf57c832cdbb69f81374da557f1e61 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal47bf57c832cdbb69f81374da557f1e61 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.star-circle','data' => ['class' => 'size-[18px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.star-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-[18px]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal47bf57c832cdbb69f81374da557f1e61)): ?>
<?php $attributes = $__attributesOriginal47bf57c832cdbb69f81374da557f1e61; ?>
<?php unset($__attributesOriginal47bf57c832cdbb69f81374da557f1e61); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal47bf57c832cdbb69f81374da557f1e61)): ?>
<?php $component = $__componentOriginal47bf57c832cdbb69f81374da557f1e61; ?>
<?php unset($__componentOriginal47bf57c832cdbb69f81374da557f1e61); ?>
<?php endif; ?>

        
        <div>Patrocinadores</div>
    </h3>

    
    <div class="space-y-3 pt-2.5">
        <?php if (isset($component)) { $__componentOriginale39b4b5e9381176fe8a574e247d3a159 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale39b4b5e9381176fe8a574e247d3a159 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sponsors.lists.docs.featured-sponsors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sponsors.lists.docs.featured-sponsors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale39b4b5e9381176fe8a574e247d3a159)): ?>
<?php $attributes = $__attributesOriginale39b4b5e9381176fe8a574e247d3a159; ?>
<?php unset($__attributesOriginale39b4b5e9381176fe8a574e247d3a159); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale39b4b5e9381176fe8a574e247d3a159)): ?>
<?php $component = $__componentOriginale39b4b5e9381176fe8a574e247d3a159; ?>
<?php unset($__componentOriginale39b4b5e9381176fe8a574e247d3a159); ?>
<?php endif; ?>
    </div>

    
    
</div>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/toc-and-sponsors.blade.php ENDPATH**/ ?>