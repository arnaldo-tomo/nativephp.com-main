<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <main
        class="mx-auto flex w-full max-w-5xl grow items-start px-4 pt-1 xl:max-w-7xl 2xl:max-w-360"
    >
        
        <?php if(! empty($sidebarLeft)): ?>
            <?php if (isset($component)) { $__componentOriginal80bc896b6e1e60934e57952fb2b9f728 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal80bc896b6e1e60934e57952fb2b9f728 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-left-navigation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-left-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php echo e($sidebarLeft); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal80bc896b6e1e60934e57952fb2b9f728)): ?>
<?php $attributes = $__attributesOriginal80bc896b6e1e60934e57952fb2b9f728; ?>
<?php unset($__attributesOriginal80bc896b6e1e60934e57952fb2b9f728); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80bc896b6e1e60934e57952fb2b9f728)): ?>
<?php $component = $__componentOriginal80bc896b6e1e60934e57952fb2b9f728; ?>
<?php unset($__componentOriginal80bc896b6e1e60934e57952fb2b9f728); ?>
<?php endif; ?>
        <?php endif; ?>

        <div class="flex w-full min-w-0 grow items-start px-2 pt-2">
            
            <article class="flex w-full min-w-0 grow flex-col lg:pl-5 xl:pr-5">
                
                <?php if (isset($component)) { $__componentOriginal65b73ac2b19d1a9b2a97f736ac7eacc1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65b73ac2b19d1a9b2a97f736ac7eacc1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.docs-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('docs-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <nav class="docs-navigation"><?php echo e($sidebarLeft); ?></nav>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65b73ac2b19d1a9b2a97f736ac7eacc1)): ?>
<?php $attributes = $__attributesOriginal65b73ac2b19d1a9b2a97f736ac7eacc1; ?>
<?php unset($__attributesOriginal65b73ac2b19d1a9b2a97f736ac7eacc1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65b73ac2b19d1a9b2a97f736ac7eacc1)): ?>
<?php $component = $__componentOriginal65b73ac2b19d1a9b2a97f736ac7eacc1; ?>
<?php unset($__componentOriginal65b73ac2b19d1a9b2a97f736ac7eacc1); ?>
<?php endif; ?>

                
                <div class="mt-3"><?php echo e($slot); ?></div>
            </article>

            
            <?php if(! empty($sidebarRight)): ?>
                <?php if (isset($component)) { $__componentOriginaleb110d187bacbd2efbc61217697b3215 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleb110d187bacbd2efbc61217697b3215 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar-right','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php echo e($sidebarRight); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleb110d187bacbd2efbc61217697b3215)): ?>
<?php $attributes = $__attributesOriginaleb110d187bacbd2efbc61217697b3215; ?>
<?php unset($__attributesOriginaleb110d187bacbd2efbc61217697b3215); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb110d187bacbd2efbc61217697b3215)): ?>
<?php $component = $__componentOriginaleb110d187bacbd2efbc61217697b3215; ?>
<?php unset($__componentOriginaleb110d187bacbd2efbc61217697b3215); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/docs-layout.blade.php ENDPATH**/ ?>