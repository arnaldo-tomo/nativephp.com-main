<?php
    $sponsors = [
        [
            'url' => 'https://www.redgalaxy.co.uk/',
            'title' => 'Learn more about RedGalaxy',
            'label' => 'Visit RedGalaxy website',
            'component' => 'sponsors.logos.redgalaxy',
            'class' => 'h-auto max-h-8 max-w-full',
            'alt' => 'RedGalaxy logo',
            'name' => 'RedGalaxy',
        ],
        [
            'url' => 'https://sevalla.com/?utm_source=nativephp&utm_medium=Referral&utm_campaign=homepage',
            'title' => 'Learn more about Sevalla',
            'label' => 'Visit Sevalla website',
            'component' => 'sponsors.logos.sevalla',
            'class' => 'h-auto max-h-8 max-w-full text-black dark:text-white',
            'alt' => 'Sevalla logo',
            'name' => 'Sevalla',
        ],
        [
            'url' => 'https://www.kaashosting.nl/?lang=en',
            'title' => 'Learn more about KaasHosting',
            'label' => 'Visit KaasHosting website',
            'component' => 'sponsors.logos.kaashosting',
            'class' => 'block h-auto max-h-8 max-w-full fill-[#042340] dark:fill-white',
            'alt' => 'KaasHosting logo',
            'name' => 'KaasHosting',
        ],
        [
            'url' => 'https://www.quantumweb.co/',
            'title' => 'Learn more about Quantumweb',
            'label' => 'Visit Quantumweb website',
            'component' => 'sponsors.logos.quantumweb',
            'class' => 'block h-auto max-h-8 max-w-full fill-[#042340] dark:fill-white',
            'alt' => 'Quantumweb logo',
            'name' => 'Quantumweb',
        ],
        // Uncomment these if you want to include the commented sponsors
        /*
                                    [
                                        'url' => 'https://serverauth.com/',
                                        'title' => 'Learn more about ServerAuth',
                                        'label' => 'Visit ServerAuth website',
                                        'component' => 'sponsors.logos.serverauth',
                                        'class' => 'block h-auto max-h-8 max-w-full fill-[#042340] dark:fill-white',
                                        'alt' => 'ServerAuth logo',
                                        'name' => 'ServerAuth'
                                    ],
                                    [
                                        'url' => 'https://borah.digital/',
                                        'title' => 'Learn more about Borah Digital Labs',
                                        'label' => 'Visit Borah Digital Labs website',
                                        'component' => 'sponsors.logos.borah',
                                        'class' => 'block h-auto max-h-8 max-w-full dark:brightness-125',
                                        'alt' => 'Borah Digital Labs logo',
                                        'name' => 'Borah Digital Labs'
                                    ],
                                */
    ];

    $randomSponsor = $sponsors[array_rand($sponsors)];
?>

<a
    href="<?php echo e($randomSponsor['url']); ?>"
    class="inline-grid h-16 w-full shrink-0 place-items-center rounded-2xl bg-gray-100 px-5 transition duration-200 will-change-transform hover:bg-gray-200/70 hover:ring-1 hover:ring-black/60 dark:bg-mirage dark:hover:bg-haiti dark:hover:ring-cloud"
    title="<?php echo e($randomSponsor['title']); ?>"
    aria-label="<?php echo e($randomSponsor['label']); ?>"
    rel="noopener"
>
    <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $randomSponsor['component']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => ''.e($randomSponsor['class']).'','alt' => ''.e($randomSponsor['alt']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
    <span class="sr-only"><?php echo e($randomSponsor['name']); ?></span>
</a>
<?php /**PATH /Users/dintell/Downloads/nativephp.com-main/resources/views/components/sponsors/lists/docs/corporate-sponsors.blade.php ENDPATH**/ ?>