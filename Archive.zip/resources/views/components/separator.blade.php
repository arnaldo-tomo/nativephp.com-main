<hr {{ $attributes->class(['dark:border-gray-700']) }}>
