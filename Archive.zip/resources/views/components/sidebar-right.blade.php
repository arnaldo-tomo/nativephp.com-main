<aside
    class="sticky top-20 hidden max-h-[clamp(15rem,100svh,88svh)] w-68 shrink-0 flex-col overflow-y-auto overflow-x-hidden px-3 py-4 xl:flex"
>
    {{ $slot }}
</aside>
