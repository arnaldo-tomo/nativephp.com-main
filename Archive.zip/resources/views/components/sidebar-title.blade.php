<div
    {{ $attributes }}
    class="mb-2 border-b pb-1 text-sm font-semibold uppercase text-gray-400 dark:border-gray-800 dark:text-gray-500"
>
    {{ $slot }}
</div>
