<svg
    {{ $attributes }}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
    fill="none"
>
    <g>
        <path
            d="M15.2257 18.9285C11.7206 18.5458 8.28883 18.5458 4.78369 18.9285"
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M18.6317 12.0969C18.4381 13.459 17.3359 14.5184 15.9919 14.6397C11.953 15.0043 8.04696 15.0043 4.00817 14.6397C2.66415 14.5184 1.56183 13.459 1.36829 12.0969C0.972289 9.30992 0.972289 6.67458 1.36829 3.88763C1.56183 2.52553 2.66415 1.46607 4.00819 1.34478C8.04696 0.980289 11.953 0.980289 15.9919 1.34478C17.3359 1.46607 18.4381 2.52553 18.6317 3.88763C19.0277 6.67458 19.0277 9.30992 18.6317 12.0969Z"
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M12.1925 14.8762C10.7296 14.9254 9.27329 14.9254 7.81041 14.8761L7.12646 18.7291C9.04714 18.6122 10.9555 18.6121 12.8761 18.7285L12.1925 14.8762Z"
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M12.1426 5.40417C12.1426 5.40417 14.2854 7.21306 14.2854 7.99215C14.2854 8.77125 12.1426 10.5801 12.1426 10.5801"
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M7.85721 5.40417C7.85721 5.40417 5.71436 7.21306 5.71436 7.99215C5.71436 8.77125 7.85721 10.5801 7.85721 10.5801"
            stroke="currentColor"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </g>
</svg>
