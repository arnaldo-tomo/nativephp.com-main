<svg
    {{ $attributes }}
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
>
    <g>
        <path
            fill="#ffef5e"
            d="m11.27 1.791 -9.586 9.586a1 1 0 0 0 0 1.414l9.586 9.585a1 1 0 0 0 1.414 0l9.585 -9.585a1 1 0 0 0 0 -1.414L12.684 1.79a1 1 0 0 0 -1.414 0Z"
            stroke-width="1"
        ></path>
        <path
            fill="#fff9bf"
            d="m2.893 14 8.376 -8.377a1 1 0 0 1 1.415 0L21.06 14l1.209 -1.209a1 1 0 0 0 0 -1.414l-9.585 -9.585a1 1 0 0 0 -1.415 0l-9.585 9.585a1 1 0 0 0 0 1.414l1.209 1.21Z"
            stroke-width="1"
        ></path>
        <path
            stroke="#191919"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="m11.27 1.791 -9.586 9.586a1 1 0 0 0 0 1.414l9.586 9.585a1 1 0 0 0 1.414 0l9.585 -9.585a1 1 0 0 0 0 -1.414L12.684 1.79a1 1 0 0 0 -1.414 0Z"
            stroke-width="1"
        ></path>
        <path
            stroke="#191919"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M12 14.109v-7"
            stroke-width="1"
        ></path>
        <path
            stroke="#191919"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M11.987 16.109a0.243 0.243 0 0 0 -0.222 0.16 0.254 0.254 0 0 0 0.238 0.34h0.009a0.248 0.248 0 0 0 0.222 -0.16 0.254 0.254 0 0 0 -0.234 -0.34"
            stroke-width="1"
        ></path>
        <path
            stroke="#191919"
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M12 16.109h-0.009"
            stroke-width="1"
        ></path>
    </g>
</svg>
