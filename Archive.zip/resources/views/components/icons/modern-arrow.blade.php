<svg
    {{ $attributes }}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 23 28"
    fill="none"
>
    <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M11.4872 0.393906L22.3968 11.3036L22.3966 11.3037L22.3967 11.3037L22.387 16.6444L14.5679 16.6302L15.2636 23.472L11.2774 27.4582L7.50096 23.6818L14.5526 16.6302L0.649884 16.6049L0.659572 11.2643L14.8305 11.29L7.71077 4.17032L11.4872 0.393906Z"
        fill="currentColor"
    />
</svg>
