<svg
    {{ $attributes }}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
    fill="none"
>
    <path
        d="M17.2934 5.15369C17.2934 5.15369 16.2195 2.46899 14.0717 1.05201C13.7015 0.807742 13.2572 0.714232 12.8136 0.714233L7.18627 0.714248C6.74271 0.714248 6.29843 0.807758 5.92819 1.05202C3.78043 2.469 2.70654 5.1537 2.70654 5.1537L17.2934 5.15369Z"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M2.70654 5.15381H17.2934"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M10 0.714233V5.15369"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M3.9749 15.4676C3.20698 15.376 2.58667 14.8117 2.46384 14.0482C2.17147 12.2308 1.82218 8.69229 2.70681 5.15382L17.2936 5.15381C18.1782 8.69197 17.8291 12.2301 17.5366 14.0477C17.4138 14.8114 16.7932 15.3759 16.0251 15.4673"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M12.9907 14.6263C12.3927 13.4301 11.1966 12.234 10.0005 11.636C8.8044 12.234 7.6083 13.4301 7.01025 14.6263"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M10 19.2856V11.6687"
        stroke="currentColor"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
</svg>
