<svg
    {{ $attributes }}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 330 330"
>
    <title>NativePHP logomark (by Caneco)</title>
    <path fill="#505b93" d="M100.6,330H0V0h100.6V330z"/>
    <path fill="#00aaa6" d="M330,330H229.4V0H330V330z"/>
    <path fill="#272d48" d="M330,330H100.6V0L330,330z"/>
</svg>
