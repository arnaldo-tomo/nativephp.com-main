<img
    {{ $attributes }}
    src="/img/sponsors/borah.webp"
    width="88"
    height="32"
/>
