---
title: Configuration
order: 200
---

# Configuração

## Visão Geral

O Laravel Lusophone é projetado para funcionar **sem configuração** na maioria dos casos. No entanto, oferece opções avançadas para personalizar o comportamento conforme as suas necessidades específicas.

## Ficheiro de Configuração

### Publicar Configuração

```bash
php artisan vendor:publish --tag=lusophone-config
```

Isto criará o ficheiro `config/lusophone.php`:


### Scripts de Deployment

```bash
#!/bin/bash
# scripts/deploy-lusophone.sh

echo "🚀 Deployment Laravel Lusophone"

# 1. Verificar requisitos
php artisan lusophone:check-requirements

# 2. Publicar configurações se necessário
if [ ! -f config/lusophone.php ]; then
    php artisan vendor:publish --tag=lusophone-config --quiet
fi

# 3. Cache de configuração para produção
if [ "$APP_ENV" = "production" ]; then
    php artisan config:cache
    php artisan lusophone:cache-translations
fi

# 4. Validar configuração
php artisan lusophone:validate-config

# 5. Teste rápido
php artisan lusophone:detect --quiet

echo "✅ Laravel Lusophone configurado com sucesso!"
```

## Exemplos de Configuração Completa

### Configuração para E-commerce Multi-país

```php
<?php
// config/lusophone.php para e-commerce

return [
    'auto_detect' => true,
    'auto_set_locale' => true,
    'default_region' => 'MZ', // Mercado principal
    
    'integrations' => [
        'breeze' => ['enabled' => true],
        'jetstream' => ['enabled' => false], // Não usar Jetstream
    ],
    
    'universal_translation' => [
        'enabled' => true,
        'cache_translations' => true,
        'fuzzy_matching' => true,
        'contexts' => [
            'product' => 'commercial',
            'checkout' => 'formal',
            'support' => 'friendly',
        ],
    ],
    
    'formatting' => [
        'currency_precision' => 2, // Sempre 2 casas decimais
        'show_currency_code' => true, // "1.500,50 MZN" em vez de "MT"
    ],
    
    'validation' => [
        'strict_mode' => true, // Validação rigorosa para transações
        'require_phone_verification' => true,
    ],
];
```
### Configuração para Sistema Governamental

```php
<?php
// config/lusophone.php para sistema governamental

return [
    'auto_detect' => true,
    'force_region' => env('GOV_REGION', 'MZ'), // Forçar país específico
    'auto_set_locale' => true,
    
    'universal_translation' => [
        'enabled' => true,
        'contexts' => [
            'legal' => 'formal',
            'public' => 'accessible',
            'internal' => 'technical',
        ],
        'fallback_to_english' => false, // Apenas português
    ],
    
    'validation' => [
        'government_mode' => true, // Validações oficiais
        'audit_validation_attempts' => true, // Log tentativas
    ],
    
    'formatting' => [
        'use_official_currency_names' => true, // "Metical" não "MT"
        'date_format_official' => true, // Formato oficial do país
    ],
];
```

## Migração e Atualização

### Migrar de Versões Anteriores

```bash
# Backup configuração atual
cp config/lusophone.php config/lusophone.backup.php

# Atualizar package
composer update arnaldotomo/laravel-lusophone

# Republicar configuração
php artisan vendor:publish --tag=lusophone-config --force

# Comparar mudanças
diff config/lusophone.backup.php config/lusophone.php

# Validar configuração nova
php artisan lusophone:validate-config
```

### Changelog de Configuração

```markdown
# Mudanças na configuração por versão

## v1.0.4 → v1.0.5
- Adicionado: `universal_translation.fuzzy_matching`
- Adicionado: `formatting.currency_precision`
- Mudança: `default_region` agora padrão 'MZ' (antes 'PT')

## v1.0.3 → v1.0.4  
- Adicionado: `integrations.jetstream`
- Adicionado: `cache.translation_ttl`
- Removido: `deprecated_option` (descontinuada)
```

## Próximos Passos

Agora que compreende as configurações do Laravel Lusophone:

1. **[Aprenda sobre validações universais](validation.md)**
2. **[Explore formatação de moedas](formatting.md)**
3. **[Personalize traduções](translations.md)**
4. **[Configure detecção de região](detection.md)**
5. **[Implemente em produção](deployment.md)**

---

**Configuração concluída! 🎛️ Agora tem controlo total sobre o comportamento do Laravel Lusophone.**
