import '@fontsource/poppins/latin.css'
