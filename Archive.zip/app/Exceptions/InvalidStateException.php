<?php

namespace App\Exceptions;

use Exception;

class InvalidStateException extends Exception
{
    //
}
